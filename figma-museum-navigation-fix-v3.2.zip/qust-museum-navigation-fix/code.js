"use strict";
/// <reference path="./plugin-api.d.ts" />
(async () => {
    try {
        const page = figma.currentPage;
        figma.notify('正在检查当前文件中的美术馆导航与按钮…', { timeout: 3000 });
        const roots = page.children.filter(n => n.type === 'FRAME' && (n.children.some(c => c.name === '纵向滚动视口') || n.children.some(c => c.name === '固定磨砂导航')));
        if (!roots.length) {
            figma.closePlugin('未找到美术馆画板。请切换到已导入美术馆的 Page，再运行本修复插件。');
            return;
        }
        const labels = { home: '现场', exhibitions: '展览', learning: '美育', services: '校园服务', profile: '我的' }, keys = Object.keys(labels);
        const idCache = new Map();
        async function lookup(id) { if (!idCache.has(id))
            idCache.set(id, await figma.getNodeByIdAsync(id)); return idCache.get(id); }
        function descend(n) { const result = []; if (n.type === 'INSTANCE')
            return result; if ('children' in n)
            for (const c of n.children) {
                result.push(c);
                result.push(...descend(c));
            } return result; }
        function clickable(n) { if ('fills' in n && Array.isArray(n.fills) && n.fills.length === 0)
            n.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: .001 }]; }
        function nearest(source, name) { return roots.filter(r => r.name === name).sort((a, b) => Math.hypot(a.x - source.x, a.y - source.y) - Math.hypot(b.x - source.x, b.y - source.y))[0]; }
        const selected = page.selection[0];
        let selectedRoot;
        if (selected)
            selectedRoot = roots.find(r => r === selected || descend(r).some(n => n.id === selected.id));
        let navCount = 0, buttonCount = 0, validExisting = 0, missingExisting = 0;
        const touched = new Set();
        for (const root of roots) {
            const bar = root.children.find(n => n.name === '固定磨砂导航');
            if (!bar)
                continue;
            // Keep the complete bar above the scrolling viewport without moving its position.
            root.appendChild(bar);
            bar.locked = false;
            const candidates = descend(bar);
            const existingDestinations = new Map();
            for (const key of keys) {
                const btn = candidates.find(n => n.name === '按钮 / 导航 / ' + key || n.name === '导航点击 / ' + labels[key]);
                if (btn && 'reactions' in btn)
                    for (const r of btn.reactions)
                        for (const a of r.actions || []) {
                            if (a.type === 'NODE' && a.destinationId) {
                                const d = await lookup(a.destinationId);
                                if ((d === null || d === void 0 ? void 0 : d.type) === 'FRAME' && (d.name === labels[key] || !roots.some(r => r.name === labels[key])))
                                    existingDestinations.set(key, d);
                            }
                        }
            }
            const anchor = existingDestinations.get('home') || nearest(root, labels.home) || root;
            for (let i = 0; i < keys.length; i++) {
                const key = keys[i], target = existingDestinations.get(key) || nearest(anchor, labels[key]);
                if (!target)
                    continue;
                let button = candidates.find(n => n.name === '按钮 / 导航 / ' + key || n.name === '导航点击 / ' + labels[key]);
                if (!button || !('setReactionsAsync' in button)) {
                    const n = figma.createRectangle();
                    n.name = '导航点击 / ' + labels[key];
                    n.x = 6 + i * (bar.width - 12) / 5;
                    n.y = 6;
                    n.resize((bar.width - 12) / 5, bar.height - 12);
                    n.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: .001 }];
                    n.constraints = { horizontal: 'SCALE', vertical: 'STRETCH' };
                    bar.appendChild(n);
                    button = n;
                }
                clickable(button);
                button.locked = false;
                await button.setReactionsAsync([{ trigger: { type: 'ON_CLICK' }, actions: [{ type: 'NODE', destinationId: target.id, navigation: 'NAVIGATE', transition: { type: 'DISSOLVE', easing: { type: 'EASE_OUT' }, duration: .16 }, resetScrollPosition: true }] }]);
                touched.add(button.id);
                navCount++;
            }
        }
        // Preserve and reapply valid existing actions, while giving entire button Frames a hit surface.
        const ours = page.children.filter(n => roots.includes(n) || /^面板 \/|^启动页 \/|^校园滑动 \/|^校园动效演示|^收藏反馈|^预约须知提示/.test(n.name));
        for (const top of ours)
            for (const n of [top, ...descend(top)]) {
                if (n.type === 'INSTANCE' || !('reactions' in n) || !n.reactions.length || touched.has(n.id))
                    continue;
                let valid = true;
                for (const r of n.reactions)
                    for (const a of r.actions || [])
                        if (a.type === 'NODE' && a.destinationId && !await lookup(a.destinationId)) {
                            valid = false;
                            missingExisting++;
                        }
                if (!valid)
                    continue;
                if (n.reactions.some(r => { var _a; return ((_a = r.trigger) === null || _a === void 0 ? void 0 : _a.type) === 'ON_CLICK'; })) {
                    clickable(n);
                    buttonCount++;
                }
                await n.setReactionsAsync([...n.reactions]);
                validExisting++;
            }
        const start = selectedRoot ? (nearest(selectedRoot, '现场') || selectedRoot) : (roots.find(r => r.name === '现场') || roots[0]);
        const flowName = '导航修复 / 点击此流程演示';
        if (!page.flowStartingPoints.some(f => f.nodeId === start.id && f.name === flowName))
            page.flowStartingPoints = [...page.flowStartingPoints, { nodeId: start.id, name: flowName }];
        figma.viewport.scrollAndZoomIntoView([start]);
        figma.closePlugin('已连接 ' + navCount + ' 个导航入口，检查 ' + validExisting + ' 个原型动作。' + (missingExisting ? '发现 ' + missingExisting + ' 个已删除目标，需手动重连。' : '') + '请点击右上角 ▶ Present，在演示窗口操作；编辑画布只会选中图层。');
    }
    catch (e) {
        figma.closePlugin('修复未完成：' + (e instanceof Error ? e.message : String(e)));
    }
})();
