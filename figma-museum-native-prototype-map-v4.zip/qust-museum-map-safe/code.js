"use strict";
/// <reference path="./plugin-api.d.ts" />
const REACTION_DIAGNOSTICS = { selfNoops: 0, invalidTargets: 0, apiRejected: 0, entries: [] };
const REACTION_NODE_CACHE = new Map();
function ownerPage(n) { for (let p = n; p; p = p.parent) {
    if (p.type === 'PAGE')
        return p;
} return null; }
function outerFrame(n) { let result = null; for (let p = n; p && p.type !== 'PAGE'; p = p.parent)
    if (p.type === 'FRAME')
        result = p; return result; }
function ownerComponent(n) { for (let p = n; p && p.type !== 'PAGE'; p = p.parent)
    if (p.type === 'COMPONENT')
        return p; return null; }
function validPrototypeTarget(source, target, navigation) {
    var _a, _b, _c, _d, _e, _f;
    if (source.removed || target.removed || !ownerPage(source) || ((_a = ownerPage(source)) === null || _a === void 0 ? void 0 : _a.id) !== ((_b = ownerPage(target)) === null || _b === void 0 ? void 0 : _b.id))
        return 'invalid';
    const from = outerFrame(source);
    if (navigation === 'NAVIGATE' || navigation === 'OVERLAY' || navigation === 'SWAP') {
        if (target.type !== 'FRAME' || ((_c = target.parent) === null || _c === void 0 ? void 0 : _c.type) !== 'PAGE')
            return 'invalid';
        if ((from === null || from === void 0 ? void 0 : from.id) === target.id)
            return 'self';
        return from ? 'ok' : 'invalid';
    }
    if (navigation === 'SCROLL_TO')
        return from && ((_d = outerFrame(target)) === null || _d === void 0 ? void 0 : _d.id) === from.id ? 'ok' : 'invalid';
    if (navigation === 'CHANGE_TO') {
        const c = ownerComponent(source);
        if (!c || target.type !== 'COMPONENT' || ((_e = c.parent) === null || _e === void 0 ? void 0 : _e.type) !== 'COMPONENT_SET' || c.parent.id !== ((_f = target.parent) === null || _f === void 0 ? void 0 : _f.id))
            return 'invalid';
        return c.id === target.id ? 'self' : 'ok';
    }
    return 'invalid';
}
async function guardedSet(n, reactions) {
    const cleaned = [];
    for (const r of reactions) {
        if (!r.trigger)
            continue;
        const actions = [];
        for (const a of r.actions || (r.action ? [r.action] : [])) {
            if (a.type !== 'NODE') {
                actions.push(a);
                continue;
            }
            const target = a.destinationId ? (REACTION_NODE_CACHE.get(a.destinationId) || await figma.getNodeByIdAsync(a.destinationId)) : null;
            if (target && a.destinationId)
                REACTION_NODE_CACHE.set(a.destinationId, target);
            const state = target ? validPrototypeTarget(n, target, a.navigation) : 'invalid';
            if (state === 'self') {
                REACTION_DIAGNOSTICS.selfNoops++;
                continue;
            }
            if (state === 'invalid') {
                REACTION_DIAGNOSTICS.invalidTargets++;
                REACTION_DIAGNOSTICS.entries.push(n.name + ' → ' + ((target === null || target === void 0 ? void 0 : target.name) || a.destinationId || '无目标') + ' [' + a.navigation + ']');
                continue;
            }
            actions.push(a);
        }
        if (actions.length)
            cleaned.push({ trigger: r.trigger, actions });
    }
    try {
        await n.setReactionsAsync(cleaned);
        return cleaned.length > 0;
    }
    catch (e) {
        REACTION_DIAGNOSTICS.apiRejected++;
        REACTION_DIAGNOSTICS.entries.push(n.name + '：' + String(e));
        return false;
    }
}
(async () => {
    try {
        const page = figma.currentPage;
        figma.notify('正在检查当前文件中的美术馆导航与按钮…', { timeout: 3000 });
        const roots = page.children.filter(n => n.type === 'FRAME' && (n.children.some(c => c.name === '纵向滚动视口') || n.children.some(c => c.name === '固定磨砂导航')));
        if (!roots.length) {
            figma.closePlugin('未找到美术馆画板。请切换到已导入美术馆的 Page，再运行本修复插件。');
            return;
        }
        const labels = { home: '现场', exhibitions: '展览', learning: '美育', services: '校园服务', profile: '我的' }, keys = Object.keys(labels);
        const idCache = new Map();
        async function lookup(id) { if (!idCache.has(id))
            idCache.set(id, await figma.getNodeByIdAsync(id)); return idCache.get(id); }
        function descend(n) { const result = []; if (n.type === 'INSTANCE')
            return result; if ('children' in n)
            for (const c of n.children) {
                result.push(c);
                result.push(...descend(c));
            } return result; }
        function clickable(n) { if ('fills' in n && Array.isArray(n.fills) && n.fills.length === 0)
            n.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: .001 }]; }
        function nearest(source, name) { return roots.filter(r => r.name === name).sort((a, b) => Math.hypot(a.x - source.x, a.y - source.y) - Math.hypot(b.x - source.x, b.y - source.y))[0]; }
        const selected = page.selection[0];
        let selectedRoot;
        if (selected)
            selectedRoot = roots.find(r => r === selected || descend(r).some(n => n.id === selected.id));
        let navCount = 0, buttonCount = 0, validExisting = 0, missingExisting = 0;
        const touched = new Set();
        for (const root of roots) {
            const bar = root.children.find(n => n.name === '固定磨砂导航');
            if (!bar)
                continue;
            // Keep the complete bar above the scrolling viewport without moving its position.
            root.appendChild(bar);
            bar.locked = false;
            const candidates = descend(bar);
            const existingDestinations = new Map();
            for (const key of keys) {
                const btn = candidates.find(n => n.name === '按钮 / 导航 / ' + key || n.name === '导航点击 / ' + labels[key]);
                if (btn && 'reactions' in btn)
                    for (const r of btn.reactions)
                        for (const a of r.actions || []) {
                            if (a.type === 'NODE' && a.destinationId) {
                                const d = await lookup(a.destinationId);
                                if ((d === null || d === void 0 ? void 0 : d.type) === 'FRAME' && (d.name === labels[key] || !roots.some(r => r.name === labels[key])))
                                    existingDestinations.set(key, d);
                            }
                        }
            }
            const anchor = existingDestinations.get('home') || nearest(root, labels.home) || root;
            for (let i = 0; i < keys.length; i++) {
                const key = keys[i], target = existingDestinations.get(key) || nearest(anchor, labels[key]);
                if (!target)
                    continue;
                let button = candidates.find(n => n.name === '按钮 / 导航 / ' + key || n.name === '导航点击 / ' + labels[key]);
                if (!button || !('setReactionsAsync' in button)) {
                    const n = figma.createRectangle();
                    n.name = '导航点击 / ' + labels[key];
                    n.x = 6 + i * (bar.width - 12) / 5;
                    n.y = 6;
                    n.resize((bar.width - 12) / 5, bar.height - 12);
                    n.fills = [{ type: 'SOLID', color: { r: 1, g: 1, b: 1 }, opacity: .001 }];
                    n.constraints = { horizontal: 'SCALE', vertical: 'STRETCH' };
                    bar.appendChild(n);
                    button = n;
                }
                clickable(button);
                button.locked = false;
                REACTION_NODE_CACHE.set(target.id, target);
                await guardedSet(button, [{ trigger: { type: 'ON_CLICK' }, actions: [{ type: 'NODE', destinationId: target.id, navigation: 'NAVIGATE', transition: { type: 'DISSOLVE', easing: { type: 'EASE_OUT' }, duration: .16 }, resetScrollPosition: true }] }]);
                touched.add(button.id);
                navCount++;
            }
        }
        // Preserve and reapply valid existing actions, while giving entire button Frames a hit surface.
        const ours = page.children.filter(n => roots.includes(n) || /^面板 \/|^启动页 \/|^校园滑动 \/|^校园动效演示|^收藏反馈|^预约须知提示/.test(n.name));
        for (const top of ours)
            for (const n of [top, ...descend(top)]) {
                if (n.type === 'INSTANCE' || !('reactions' in n) || !n.reactions.length || touched.has(n.id))
                    continue;
                let valid = true;
                for (const r of n.reactions)
                    for (const a of r.actions || [])
                        if (a.type === 'NODE' && a.destinationId && !await lookup(a.destinationId)) {
                            valid = false;
                            missingExisting++;
                        }
                if (!valid)
                    continue;
                if (n.reactions.some(r => { var _a; return ((_a = r.trigger) === null || _a === void 0 ? void 0 : _a.type) === 'ON_CLICK'; })) {
                    clickable(n);
                    buttonCount++;
                }
                await guardedSet(n, [...n.reactions]);
                validExisting++;
            }
        const available = page.children.filter(n => n.type === 'FRAME');
        const home = selectedRoot ? (nearest(selectedRoot, '现场') || selectedRoot) : ([...roots].filter(n => n.name === '现场').sort((a, b) => b.x - a.x)[0] || roots[0]);
        const near = (predicate) => available.filter(predicate).sort((a, b) => Math.hypot(a.x - home.x, a.y - home.y) - Math.hypot(b.x - home.x, b.y - home.y))[0];
        const main = (name) => near(n => n.name === name);
        const titleFont = (await figma.listAvailableFontsAsync()).map(n => n.fontName).find(n => /Noto Sans SC|Noto Sans CJK SC|PingFang SC|Microsoft YaHei/.test(n.family) && n.style === 'Regular') || { family: 'Inter', style: 'Regular' };
        await figma.loadFontAsync(titleFont);
        const color = (s) => ({ r: parseInt(s.slice(1, 3), 16) / 255, g: parseInt(s.slice(3, 5), 16) / 255, b: parseInt(s.slice(5, 7), 16) / 255 });
        const fill = (s) => ({ type: 'SOLID', color: color(s) });
        function box(parent, name, x, y, w, h, c) { const n = figma.createFrame(); n.name = name; n.x = x; n.y = y; n.resize(w, h); n.fills = [fill(c)]; parent.appendChild(n); return n; }
        function text(parent, value, x, y, size, c = '#173D60') { const n = figma.createText(); n.name = value; n.fontName = titleFont; n.fontSize = size; n.characters = value; n.fills = [fill(c)]; n.x = x; n.y = y; parent.appendChild(n); return n; }
        const right = Math.max(0, ...page.children.map(n => { const b = n.absoluteBoundingBox; return b ? b.x + b.width : n.x + n.width; }));
        const board = box(page, '交互总览 / 青科大美术馆原生原型图', right + 700, 0, 1780, 1510, '#F5F8FC');
        board.cornerRadius = 24;
        text(board, '青科大美术馆 · 原型交互总览', 40, 32, 30, '#00529B');
        text(board, '节点可编辑；在 Present 中点击节点可查看对应画板。应用内按钮继续保留原生 Prototype 连线。', 42, 84, 14, '#65819B');
        let arrowPaths = [];
        const cards = {};
        let mapLinks = 0;
        async function card(key, title, note, x, y, target, overlay = false) {
            const n = box(board, '节点 / ' + title, x, y, 300, 98, '#FFFFFF');
            n.cornerRadius = 15;
            n.strokes = [fill('#DCE7F1')];
            n.strokeWeight = 1;
            text(n, title, 18, 17, 19, target ? '#174F80' : '#8A9AA8');
            text(n, note, 18, 55, 11, '#7A8FA3');
            text(n, target ? '↗' : '待补充', 266, 17, 16, '#6D8DA9');
            if (target) {
                REACTION_NODE_CACHE.set(target.id, target);
                await guardedSet(n, [{ trigger: { type: 'ON_CLICK' }, actions: [{ type: 'NODE', destinationId: target.id, navigation: overlay ? 'OVERLAY' : 'NAVIGATE', transition: { type: 'DISSOLVE', easing: { type: 'EASE_OUT' }, duration: .18 }, resetScrollPosition: !overlay }] }]);
                mapLinks++;
            }
            cards[key] = n;
            return n;
        }
        function edge(from, to, dashed = false, branch = false) {
            const a = cards[from], b = cards[to];
            if (!a || !b)
                return;
            let path, tx, ty;
            if (branch) {
                const sx = a.x + a.width / 2, sy = a.y + a.height;
                tx = b.x + b.width / 2;
                ty = b.y + b.height;
                path = `M ${sx} ${sy} C ${sx} ${sy + 65}, ${tx} ${ty + 65}, ${tx} ${ty}`;
                arrowPaths.push(`<path d="${path}"/><path d="M ${tx - 5} ${ty + 9} L ${tx} ${ty} L ${tx + 5} ${ty + 9}"/>`);
            }
            else {
                const sx = a.x + a.width, sy = a.y + a.height / 2;
                tx = b.x;
                ty = b.y + b.height / 2;
                path = `M ${sx + 2} ${sy} C ${sx + 26} ${sy}, ${tx - 26} ${ty}, ${tx - 2} ${ty}`;
                arrowPaths.push(`<path d="${path}" ${dashed ? 'stroke-dasharray="5 5"' : ''}/><path d="M ${tx - 10} ${ty - 5} L ${tx - 2} ${ty} L ${tx - 10} ${ty + 5}"/>`);
            }
        }
        const xs = [40, 390, 740, 1090, 1440];
        text(board, '01 / 主导航：五个入口在所有手机画板中互相连接', 40, 128, 15, '#416A8C');
        const navLabels = ['现场', '展览', '美育', '校园服务', '我的'];
        for (let i = 0; i < 5; i++)
            await card('nav' + i, navLabels[i], '点击打开主画板 · 底部导航可继续切换', xs[i], 166, main(navLabels[i]));
        for (let i = 0; i < 4; i++)
            edge('nav' + i, 'nav' + (i + 1));
        const detail = near(n => n.name === '展览详情 / 未定式');
        const booking = near(n => n.name.startsWith('面板 / 预约 / 未定式 / 校内师生 / 06.11 / 待勾选'));
        const ticket = near(n => n.name.startsWith('面板 / 预约结果 / 未定式 / 06.11'));
        text(board, '02 / 看展与预约：选择身份、日期和须知，进入结果状态', 40, 318, 15, '#416A8C');
        await card('ex', '展览列表', '正在发生 · 类别筛选', xs[0], 356, main('展览'));
        await card('detail', '展览详情', '海报 · 策展信息 · 作品与收藏', xs[1], 356, detail);
        await card('booking', '预约参观', '身份 / 日期 / 须知 · 预设交互状态', xs[2], 356, booking, true);
        await card('ticket', '预约结果', '展示预设确认结果与返回入口', xs[3], 356, ticket, true);
        await card('profile', '个人中心', '预约、收藏与活动入口', xs[4], 356, main('我的'));
        ['ex', 'detail', 'booking', 'ticket'].forEach((key, i) => edge(key, ['detail', 'booking', 'ticket', 'profile'][i], i === 1 || i === 2));
        text(board, '03 / 校园美育：发现活动、查看说明与报名反馈', 40, 508, 15, '#416A8C');
        const event = near(n => n.name === '面板 / 小志工坊'), registered = near(n => n.name === '面板 / 报名反馈');
        await card('learn', '美育与学术', '工坊 / 对谈 / 课程分类', xs[0], 546, main('美育'));
        await card('event', '活动详情', '参与对象、内容和演示报名', xs[1], 546, event, true);
        await card('registered', '报名反馈', '完成状态与个人中心入口', xs[2], 546, registered, true);
        await card('activity', '我的活动', '在个人中心查看活动入口', xs[3], 546, main('我的'));
        edge('learn', 'event', true);
        edge('event', 'registered', true);
        edge('registered', 'activity');
        text(board, '04 / 学生创作与校园支持：作品、投稿和服务说明', 40, 698, 15, '#416A8C');
        await card('creators', '学生创作', '视觉设计 / 书法 / 园林 / 纸艺', xs[0], 736, main('学生创作'));
        await card('work', '作品详情', '查看创作示例与授权说明', xs[1], 736, near(n => n.name === '面板 / 作品 · 书法'), true);
        await card('submission', '投稿说明', '准备作品、署名和展示授权', xs[2], 736, near(n => n.name === '面板 / 创作投稿'), true);
        await card('service', '校园服务', '来馆、交通、无障碍与帮助', xs[3], 736, main('校园服务'));
        await card('access', '无障碍说明', '服务指南弹层 · 可关闭返回', xs[4], 736, near(n => n.name === '面板 / 无障碍服务'), true);
        edge('creators', 'work', true);
        edge('creators', 'submission', true, true);
        edge('service', 'access', true);
        text(board, '05 / 局部交互与辅助入口', 40, 936, 15, '#416A8C');
        await card('campus', '校园卡片动效', '原生横向滚动 + Smart Animate 流程', xs[0], 974, near(n => n.name === '校园动效演示'));
        await card('search', '展览搜索', '原生版使用预设结果，结果可点', xs[1], 974, near(n => n.name === '面板 / 展览搜索'), true);
        await card('favorites', '我的收藏', '原生收藏入口与反馈画面', xs[2], 974, near(n => n.name === '面板 / 我的收藏'), true);
        await card('visitor', '校外访客服务', '切换身份，核对入校与入馆', xs[3], 974, main('校园服务 / visitor'));
        await card('help', '咨询与帮助', '常见问题与联系说明', xs[4], 974, near(n => n.name === '面板 / 咨询帮助'), true);
        text(board, '06 / 使用方式', 40, 1158, 18, '#00529B');
        text(board, '编辑画布：查看关系、改文字、调整节点和连线。选择实际按钮后，在右侧 Prototype 修改真实目标。', 42, 1200, 14, '#58748C');
        text(board, '▶ Present：选择“原型图 / 总览”看关系，或选择“原生应用 / 首页”进入手机应用，点击导航和卡片。', 42, 1234, 14, '#58748C');
        text(board, '实线表示页面路径，虚线表示面板或局部交互。示意线是可编辑矢量；真正跳转保存在 Prototype 反应中。', 42, 1268, 14, '#58748C');
        text(board, '原生图使用预设状态；实时输入、完整收藏/记录联动和本地文件处理仍在 V9 完整交互窗口中体验。', 42, 1302, 14, '#58748C');
        text(board, '这个插件不新建 Page，不覆盖现有画板。图内节点只是入口，手机画板仍保持可编辑。', 42, 1336, 14, '#58748C');
        const lines = figma.createNodeFromSvg(`<svg xmlns="http://www.w3.org/2000/svg" width="1780" height="1510" viewBox="0 0 1780 1510"><g fill="none" stroke="#9DB7CE" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${arrowPaths.join('')}</g></svg>`);
        lines.name = '流程示意连线 / 可编辑矢量';
        lines.x = 0;
        lines.y = 0;
        board.insertChild(0, lines);
        const nativeFlows = [{ nodeId: board.id, name: 'v4.1 修复 / 总览与路径' }, { nodeId: home.id, name: '原生应用 / 首页点击体验' }];
        for (const title of ['展览', '美育', '校园服务', '我的']) {
            const n = main(title);
            if (n)
                nativeFlows.push({ nodeId: n.id, name: '原生应用 / ' + title });
        }
        page.flowStartingPoints = [...page.flowStartingPoints, ...nativeFlows.filter(f => !page.flowStartingPoints.some(x => x.nodeId === f.nodeId && x.name === f.name))];
        figma.viewport.scrollAndZoomIntoView([board]);
        figma.closePlugin('已生成兼容连线规则的原型总览：' + mapLinks + ' 个可点击节点，保留 ' + navCount + ' 个导航入口。画布可编辑关系图，Present 中可点入手机画板。');
    }
    catch (e) {
        figma.closePlugin('修复未完成：' + (e instanceof Error ? e.message : String(e)));
    }
})();
