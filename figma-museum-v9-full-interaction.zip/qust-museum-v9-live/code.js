"use strict";
/// <reference path="./plugin-api.d.ts" />
figma.showUI(__html__, { width: 420, height: 900, themeColors: false, title: '青科大美术馆 · V9 完整交互体验' });
figma.ui.onmessage = async (message) => {
    const m = message;
    if ((m === null || m === void 0 ? void 0 : m.type) === 'close-live-demo')
        figma.closePlugin();
    if ((m === null || m === void 0 ? void 0 : m.type) === 'return-to-design') {
        const frames = figma.currentPage.children.filter(n => n.type === 'FRAME' && (n.name === '现场' || n.name === '首页'));
        if (frames.length)
            figma.viewport.scrollAndZoomIntoView([frames[frames.length - 1]]);
        figma.closePlugin(frames.length ? '已返回可编辑画板。' : '已关闭演示。当前页未找到首页画板，你可以切换到已有设计的 Page。');
    }
};
