const C={bg:{r:.984,g:.976,b:.957},surface:{r:1,g:.996,b:.986},ink:{r:.08,g:.07,b:.055},muted:{r:.46,g:.44,b:.4},line:{r:.92,g:.9,b:.86},dark:{r:.05,g:.04,b:.03},white:{r:1,g:1,b:1},sage:{r:.42,g:.56,b:.35},peach:{r:.98,g:.86,b:.82}};
const paint=c=>[{type:'SOLID',color:c}];
let IMAGE_POOL=[];
let ASSET_HASHES={};
const REMOTE_ASSETS={
  kyoto:'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80',
  tokyo:'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1200&q=80',
  torii:'https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=1200&q=80',
  dali:'https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1200&q=80',
  iceland:'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  bali:'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=1200&q=80',
  paris:'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80',
  bangkok:'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80',
  santorini:'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1200&q=80'
};
const font={family:'Inter',style:'Regular'};
const medium={family:'Inter',style:'Medium'};
const semi={family:'Inter',style:'Semi Bold'};
async function loadRemoteImages(){for(const [key,url] of Object.entries(REMOTE_ASSETS)){try{const res=await fetch(url);if(!res.ok)continue;const bytes=new Uint8Array(await res.arrayBuffer());ASSET_HASHES[key]=figma.createImage(bytes).hash;}catch(e){}}}
async function loadFonts(){for(const f of [font,medium,semi,{family:'Inter',style:'Bold'}])await figma.loadFontAsync(f);}
function frame(parent,name,x,y,w,h,fill=C.surface,r=16,border=null){const n=figma.createFrame();n.name=name;n.x=x;n.y=y;n.resize(w,h);n.fills=paint(fill);n.cornerRadius=r;if(border){n.strokes=paint(border);n.strokeWeight=1;}if(parent)parent.appendChild(n);return n;}
function text(parent,name,value,x,y,size=16,color=C.ink,style=font,width=null){const n=figma.createText();n.name=name;n.fontName=style;n.fontSize=size;n.characters=value;n.fills=paint(color);n.x=x;n.y=y;n.textAutoResize=width?'HEIGHT':'WIDTH_AND_HEIGHT';if(width)n.resize(width,Math.max(24,size*1.4));parent.appendChild(n);return n;}
function icon(parent,name,value,x,y,size=22,color=C.ink){return text(parent,name,value,x,y,size,color,font);}
function pill(parent,name,label,x,y,w,h,fill=C.surface,color=C.ink,border=C.line,size=14){const n=frame(parent,name,x,y,w,h,fill,h/2,border);text(n,'Label',label,16,(h-size)/2-1,size,color,medium);return n;}
function photo(parent,name,x,y,w,h,color,r=22){const n=frame(parent,name,x,y,w,h,color,r);const q=name.toLowerCase();const tokens=q.split(/[^a-z0-9]+/).filter(t=>t.length>2);const key=tokens.find(t=>ASSET_HASHES[t])||tokens.find(t=>['kyoto','tokyo','dali','iceland','bali','paris','bangkok','santorini','torii'].includes(t));const hash=key&&ASSET_HASHES[key]||IMAGE_POOL.find(x=>tokens.some(t=>x.name.toLowerCase().includes(t)))?.hash||IMAGE_POOL[0]?.hash||ASSET_HASHES.kyoto;if(hash)n.fills=[{type:'IMAGE',scaleMode:'FILL',imageHash:hash}];return n;}
function nav(screen,y,active){frame(screen,'Bottom Nav',0,y,390,78,C.surface,0,C.line);const items=[['首页','⌂',58],['探索','⌕',152],['行程','⌁',244],['我的','♙',330]];for(const [label,glyph,x] of items){const c=active===label?C.ink:C.muted;icon(screen,label+' Icon',glyph,x,y+18,21,c);text(screen,label+' Label',label,x-5,y+47,12,c,active===label?semi:font);}}
function backAction(){return{trigger:{type:'ON_CLICK'},actions:[{type:'BACK'}]};}
function navigate(dest){return{trigger:{type:'ON_CLICK'},actions:[{type:'NODE',destinationId:dest.id,navigation:'NAVIGATE',transition:{type:'DISSOLVE',easing:{type:'EASE_IN_AND_OUT'},duration:.3}}]};}
const connections=[];
function link(source,dest){if(source&&dest)connections.push([source,[navigate(dest)]]);}
function linkBack(source){if(source)connections.push([source,[backAction()]]);}
function screen(name,x,y,h){return frame(null,name,x,y,390,h,C.bg,24);}
async function main(){
 await loadFonts();
 await loadRemoteImages();
 const page=figma.currentPage;
 IMAGE_POOL=[];
 for(const n of page.findAll(x=>'fills' in x)){if(Array.isArray(n.fills))for(const f of n.fills)if(f.type==='IMAGE'&&f.imageHash)IMAGE_POOL.push({name:n.name,hash:f.imageHash});}
 const existing=page.children.filter(n=>n.name.indexOf('Travel UI /')===0);
 const startX=existing.length?Math.max(...existing.map(n=>n.x+n.width))+120:Math.max(0,...page.children.map(n=>n.x+n.width))+120;
 const home=screen('Travel UI / 01 Home · Travel 2026',startX,80,1200);
 text(home,'Eyebrow','H i ,   T r a v e l e r',28,26,12,C.muted,medium);text(home,'Title','下一站，去哪里？',28,54,26,C.ink,semi);
 const community=pill(home,'Community','◉ 社区',232,28,108,48);const bell=frame(home,'Notifications',350,28,48,48,C.surface,24,C.line);icon(bell,'Bell','♧',13,9,22);
 const search=frame(home,'Search Field',28,106,334,64,C.surface,32,C.line);icon(search,'Search Icon','⌕',18,17,24,C.muted);text(search,'Placeholder','搜索目的地',56,18,16,C.muted,medium);const filter=frame(search,'Filter Button',278,10,44,44,C.dark,22);icon(filter,'Filter Glyph','≡',12,8,23,C.white);
 const hero=photo(home,'Hero Image · Kyoto',28,198,334,330,{r:.35,g:.28,b:.2},24);text(hero,'Kicker','Japan · Kansai',26,28,12,C.white,medium);text(hero,'Hero Title','KYOTO',26,214,42,C.white,semi);text(hero,'Hero Subtitle','京都',26,264,15,C.white);const heroArrow=frame(hero,'Hero Arrow',274,24,44,44,C.surface,22);icon(heroArrow,'Glyph','↗',12,8,22);
 text(home,'Hot Heading','热门目的地',28,568,18,C.ink,semi);text(home,'Hot More','全部  ›',322,570,13,C.muted,medium);pill(home,'Tokyo Chip','东京  Tokyo',28,598,112,48,C.dark,C.white,C.dark);pill(home,'Kyoto Chip','京都  Kyoto',150,598,120,48);pill(home,'Dali Chip','大理  Dali',278,598,112,48);
 text(home,'Reco Heading','为你推荐',28,674,18,C.ink,semi);text(home,'Reco More','Editorial',307,676,12,C.muted,medium);
 const rec=[['Tokyo',28,710,'TOKYO','东京 · 城市漫游','4 DAYS',{r:.12,g:.16,b:.2}],['Iceland',205,710,'ICELAND','冰岛 · 极光公路','7 DAYS',{r:.33,g:.42,b:.46}],['Dali',28,904,'DALI','大理 · 山海之间','3 DAYS',{r:.62,g:.66,b:.56}],['Paris',205,904,'PARIS','巴黎 · 美术馆散步','5 DAYS',{r:.55,g:.42,b:.34}]];
 for(const [name,x,y,title,sub,days,col] of rec){const card=frame(home,name+' Card',x,y,157,190,C.bg,0);const img=photo(card,name+' Image',0,0,157,140,col,22);pill(img,'Duration',days,12,12,74,30,C.surface,C.muted,C.line,11);text(card,'Card Title',title,0,148,17,C.ink,medium);text(card,'Card Subtitle',sub,0,173,12,C.muted);}
 nav(home,1110,'首页');
 const explore=screen('Travel UI / 02 Explore · Search',startX+440,80,844);text(explore,'Title','探索目的地',64,27,24,C.ink,semi);text(explore,'Search','⌕  搜索城市、国家或主题',28,94,16,C.muted,medium);text(explore,'Section','热门搜索',28,180,18,C.ink,semi);pill(explore,'Tag1','城市漫游',28,214,104,42);pill(explore,'Tag2','自然风光',142,214,104,42);pill(explore,'Tag3','美食',256,214,76,42);text(explore,'Section2','编辑精选',28,292,18,C.ink,semi);for(let i=0;i<3;i++){const row=frame(explore,'Result '+i,28,330+i*112,334,92,C.surface,18,C.line);photo(row,'Thumb',12,12,68,68,{r:.45,g:.42,b:.35},14);text(row,'Name',['Kyoto','Reykjavík','Paris'][i],94,18,16,C.ink,medium);text(row,'Meta',['京都 · 4 days','冰岛 · 7 days','巴黎 · 5 days'][i],94,44,12,C.muted);icon(row,'Chevron','›',304,31,22,C.muted);}nav(explore,766,'探索');
 const communityPage=screen('Travel UI / 03 Community · Stories',startX+880,80,844);text(communityPage,'Title','旅行社区',64,27,24,C.ink,semi);pill(communityPage,'Tab1','关注',28,94,92,42,C.dark,C.white,C.dark);pill(communityPage,'Tab2','发现',128,94,92,42);pill(communityPage,'Tab3','附近',228,94,92,42);text(communityPage,'Section','旅人故事',28,176,18,C.ink,semi);for(let i=0;i<2;i++){const post=frame(communityPage,'Story '+i,28,216+i*214,334,188,C.surface,20,C.line);photo(post,'Story Image',0,0,334,112,i?{r:.35,g:.42,b:.48}:{r:.4,g:.3,b:.2},20);text(post,'Story Title',i?'在冰岛公路上看见风的形状':'京都的黄昏，慢一点就很好',16,126,16,C.ink,medium);text(post,'Story Meta',i?'Leo · 昨天':'Mia · 2 小时前',16,154,12,C.muted);}nav(communityPage,766,'我的');
 const detail=screen('Travel UI / 04 Kyoto · Detail',startX+1320,80,844);const dh=photo(detail,'Detail Hero',0,0,390,300,{r:.35,g:.28,b:.2},0);icon(dh,'Back','←',24,24,24,C.white);text(dh,'Kicker','Japan · Kansai',28,192,12,C.white,medium);text(dh,'Title','KYOTO',28,220,42,C.white,semi);text(dh,'Subtitle','京都',28,270,15,C.white);const dp=frame(detail,'Detail Panel',0,276,390,568,C.bg,28);text(dp,'Title','京都，四日慢游',28,34,24,C.ink,semi);text(dp,'Copy','从清晨的寺院，到傍晚的灯笼街。把城市留给脚步，也留给自己。',28,78,15,C.muted,font,330);pill(dp,'Save','♡  收藏',28,150,112,42);pill(dp,'Share','↗  分享',150,150,112,42,C.dark,C.white,C.dark);nav(detail,766,'行程');
 const collections=screen('Travel UI / 05 Explore Collections',startX+1760,80,1620);text(collections,'Eyebrow','J o u r n a l  ·  0 8  C o l l e c t i o n s',28,28,12,C.muted,medium);text(collections,'Title','EXPLORE',28,62,38,C.ink);text(collections,'Subtitle','探索新的目的地',28,112,16,C.muted);for(const [l,x,a] of [['全部',28,true],['城市',118,false],['自然',208,false],['海岛',298,false]])pill(collections,'Category '+l,l,x,148,80,42,a?C.sage:C.surface,a?C.white:C.ink,a?C.sage:C.line);text(collections,'Destinations','Destinations',28,232,13,C.muted,medium);text(collections,'Count','8 Places',310,232,13,C.muted,medium);
 const coll=[['Tokyo',28,268,157,370,'TOKYO','东京',{r:.18,g:.25,b:.35}],['Kyoto',205,306,157,205,'KYOTO','京都',{r:.48,g:.14,b:.05}],['Dali',28,654,157,205,'DALI','大理',{r:.55,g:.28,b:.4}],['Iceland',205,535,157,380,'ICELAND','冰岛',{r:.35,g:.48,b:.5}],['Bali',28,877,157,245,'BALI','巴厘岛',{r:.28,g:.55,b:.3}],['Paris',205,937,157,290,'PARIS','巴黎',{r:.5,g:.4,b:.3}],['Santorini',28,1140,157,205,'SANTORINI','圣托里尼',{r:.42,g:.62,b:.72}],['Bangkok',205,1257,157,250,'BANGKOK','曼谷',{r:.6,g:.35,b:.12}]];
 let kyotoCollection=null;for(const [name,x,y,w,h,title,sub,col] of coll){const c=photo(collections,name+' Collection',x,y,w,h,col,22);text(c,'Title',title,18,h-62,20,C.white,medium);text(c,'Subtitle',sub,18,h-34,13,{r:.92,g:.9,b:.84});if(name==='Kyoto')kyotoCollection=c;}nav(collections,1542,'探索');
 const destination=screen('Travel UI / 06 Kyoto Destination',startX+2200,80,1420);const kh=photo(destination,'Kyoto Hero',0,0,390,360,{r:.35,g:.28,b:.2},0);icon(kh,'Back','←',24,24,24,C.white);icon(kh,'Bookmark','♡',330,24,24,C.white);text(kh,'Kicker','日本 · 关西',28,254,13,C.white,medium);text(kh,'Title','KYOTO',28,286,40,C.white);text(kh,'Subtitle','京都',28,334,15,C.white);const panel=frame(destination,'Content',0,330,390,996,C.bg,28);frame(panel,'Handle',168,22,54,5,{r:.88,g:.84,b:.76},3);text(panel,'Intro','一千年的都城。寺庙、庭园、茶室与町屋在鸭川两岸层层展开，适合放慢脚步，一天只走一小片区域。',28,62,15,C.muted,font,334);const season=frame(panel,'Season Card',28,154,334,164,{r:.98,g:.96,b:.9},22,C.line);text(season,'Label','▣  最佳旅行时间',22,22,12,C.muted,medium);text(season,'Value','3–5月',22,58,28);text(season,'Meta','春樱 · 平均 14°C',242,66,12,C.muted);text(season,'Copy','樱花与枫叶之间的两个短暂季节，气候温和，古都的木质街巷与庭园在柔光里最好看。',22,110,12,C.muted,font,290);text(panel,'Must','必去地点',28,354,18,C.ink,semi);const must=[['Kiyomizu','清水寺','Kiyomizu-dera',{r:.5,g:.35,b:.25}],['Fushimi','伏见稻荷大社','Fushimi Inari',{r:.58,g:.18,b:.06}],['Arashiyama','岚山','Arashiyama',{r:.3,g:.52,b:.28}],['Gion','祇园','Gion',{r:.1,g:.12,b:.12}]];let templeCard=null;for(let i=0;i<4;i++){const [name,title,meta,col]=must[i];const c=frame(panel,name+' Must Card',i%2?205:28,390+Math.floor(i/2)*170,157,150,C.bg,18);photo(c,name+' Image',0,0,157,100,col,18);text(c,'Name',title,0,108,14,C.ink,medium);text(c,'Meta',meta,0,130,11,C.muted);if(name==='Kiyomizu')templeCard=c;}const cta=frame(panel,'Plan CTA',28,730,334,180,C.dark,28);text(cta,'Days','3 天',24,20,28,C.white);text(cta,'Nights','2 晚',24,58,12,{r:.75,g:.72,b:.66});pill(cta,'Route','推荐路线　→',24,98,286,56,C.surface);nav(destination,1342,'行程');
 const temple=screen('Travel UI / 07 Kiyomizu Detail',startX+2640,80,1450);const th=photo(temple,'Kiyomizu Hero',0,0,390,360,{r:.25,g:.18,b:.12},0);icon(th,'Back','←',24,24,24,C.white);pill(th,'Save','♡ 收藏',278,24,88,44,{r:.2,g:.17,b:.15},C.white,{r:.2,g:.17,b:.15});text(th,'Kicker','TEMPLE',28,258,12,{r:.9,g:.84,b:.76},medium);text(th,'Title','KIYOMIZU-DERA',28,288,30,C.white);text(th,'Subtitle','清水寺',28,332,15,C.white);const tp=frame(temple,'Content',0,330,390,1028,C.bg,28);frame(tp,'Handle',168,22,54,5,{r:.88,g:.84,b:.76},3);text(tp,'Rating','4.8',28,62,28,C.ink,semi);text(tp,'Stars','★ ★ ★ ★ ★',86,68,17,{r:.78,g:.38,b:.28});text(tp,'Reviews','1,286 reviews  ›',274,70,12,C.muted);text(tp,'Kicker','K Y O T O  /  J A P A N',28,116,12,C.muted,medium);text(tp,'Description','悬空的木舞台上，京都的四季尽收眼底。江户时代兴建的清水寺，是古都最具代表性的地标，春樱秋枫，无论何时到访都值得停留。',28,154,15,C.muted,font,334);const info=frame(tp,'Info Card',28,282,334,274,{r:.98,g:.96,b:.9},22,C.line);const rows=[['◷','开放时间','06:00 – 18:00'],['▣','门票','¥400'],['☼','最佳时段','清晨'],['⌖','地址','京都 · 东山']];for(let i=0;i<rows.length;i++){const y=18+i*64;if(i)frame(info,'Divider '+i,22,y-8,290,1,C.line,0);icon(info,'Icon '+i,rows[i][0],24,y+2,18,C.muted);text(info,'Label '+i,rows[i][1],64,y+4,12,C.muted);text(info,'Value '+i,rows[i][2],224,y+4,14,C.ink,medium);}text(tp,'Tips','TRAVEL TIPS',28,596,16,C.ink,medium);for(let i=0;i<3;i++){const row=frame(tp,'Tip '+i,28,638+i*80,334,62,C.surface,18,C.line);const badge=frame(row,'Badge',14,13,36,36,C.peach,18);icon(badge,'Icon','◉',9,7,18,{r:.68,g:.32,b:.24});text(row,'Text',['适合摄影','避开高峰时段','推荐日落时分'][i],68,20,15,C.ink,medium);}const actions=frame(tp,'Action Bar',0,888,390,88,C.surface,0,C.line);pill(actions,'Add','＋ 加入行程',28,20,170,48,C.dark,C.white,C.dark);pill(actions,'Route','▷ 获取路线',208,20,154,48);nav(temple,1372,'探索');
 // Prototype wiring after all screens exist.
 link(community,communityPage);link(bell,communityPage);link(search,explore);link(filter,explore);link(heroArrow,detail);link(home.findOne(n=>n.name==='探索 Icon'),collections);link(kyotoCollection,destination);link(templeCard,temple);link(destination.findOne(n=>n.name==='Back'),home);link(temple.findOne(n=>n.name==='Back'),destination);linkBack(explore.findOne(n=>n.name==='Back'));linkBack(communityPage.findOne(n=>n.name==='Back'));linkBack(detail.findOne(n=>n.name==='Back'));linkBack(destination.findOne(n=>n.name==='Back'));linkBack(temple.findOne(n=>n.name==='Back'));
 for(const s of [home,explore,communityPage,detail,collections,destination,temple]) {
  for(const [label,target] of [['首页',home],['探索',collections],['行程',destination],['我的',communityPage]]) {
   if(s!==target) {link(s.findOne(n=>n.name===label+' Icon'),target);link(s.findOne(n=>n.name===label+' Label'),target);}
  }
 }
 link(detail.findOne(n=>n.name==='Detail Hero'),destination);
 link(cta.findOne(n=>n.name==='Route'),temple);
 const latest=new Map(connections);
 for(const [node,reactions] of latest) await node.setReactionsAsync(reactions);
 figma.ui.postMessage({type:'done',screens:7,links:latest.size,images:IMAGE_POOL.length+Object.keys(ASSET_HASHES).length});
 figma.currentPage.selection=[home,explore,communityPage,detail,collections,destination,temple];figma.viewport.scrollAndZoomIntoView([home,explore,communityPage,detail,collections,destination,temple]);
}
figma.showUI(__html__,{width:340,height:280});
let running=false;
figma.ui.onmessage=async function(msg){
 if(msg.type==='close'){figma.closePlugin();return;}
 if(msg.type!=='run'||running)return;
 running=true;
 try { await main(); } catch(e) {figma.ui.postMessage({type:'error',message:String(e)});} finally {running=false;}
};
