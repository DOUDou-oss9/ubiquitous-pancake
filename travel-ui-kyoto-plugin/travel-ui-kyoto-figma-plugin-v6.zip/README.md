# Travel UI · Kyoto Prototype

[下载带图片和交互的 Figma 插件包](./travel-ui-kyoto-figma-plugin-v5.zip)

下载 ZIP 后解压，在 Figma 中选择 **插件 → 开发 → 从 manifest 导入插件**，选择解压目录里的 `manifest.json`，然后运行插件。

插件会生成 7 个可编辑移动端画板和基础 Prototype 连线：首页、探索、社区、京都详情、Explore Collections、Kyoto Destination、Kiyomizu Detail。

插件会自动加载旅行图片，并优先使用目的地对应图片；如果原 Figma 文件已有图片填充，也会复用现有图片。新页面不会再只显示色块。
