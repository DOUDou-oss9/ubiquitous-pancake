# Travel UI · Kyoto Prototype

[下载 Figma 插件包](./travel-ui-kyoto-figma-plugin-v3.zip)

下载 ZIP 后解压，在 Figma 中选择 **插件 → 开发 → 从 manifest 导入插件**，选择解压目录里的 `manifest.json`，然后运行插件。

插件会生成 7 个可编辑移动端画板和基础 Prototype 连线：首页、探索、社区、京都详情、Explore Collections、Kyoto Destination、Kiyomizu Detail。

插件会扫描当前 Page 的现有图片填充，并按目的地名称复用到新增画板；这样在原有 Travel UI 文件中运行时，原本的旅行图片会自动带入新页面。
