# Travel UI · Kyoto Prototype

[下载 Figma 插件包](./travel-ui-figma-plugin.zip)

这是一个 Figma 开发插件安装包。下载 ZIP 后解压，在 Figma 中选择 **插件 → 开发 → 从 manifest 导入插件**，选择解压目录内的 `manifest.json`，然后运行插件。

插件会生成 7 个可编辑移动端画板，并创建基础 Prototype 连线：主页、探索、社区、京都详情、Explore Collections、Kyoto Destination、Kiyomizu Detail。
